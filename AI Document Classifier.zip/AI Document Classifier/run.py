
import subprocess
import sys
import os

# Ensure we run from project root
script_path = os.path.join(os.path.dirname(__file__), "src", "ui.py")

# Launch Streamlit
subprocess.run([sys.executable, "-m", "streamlit", "run", script_path])