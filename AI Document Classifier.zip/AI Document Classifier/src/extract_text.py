import pdfplumber

def extract_text(pdf_path, max_pages=2):
    """
    Extract text from the first few pages of a PDF.
    """
    text = ""
    try:
        with pdfplumber.open(pdf_path) as pdf:
            total_pages = min(max_pages, len(pdf.pages))
            for i in range(total_pages):
                # Clean up the text extraction slightly to handle noisy PDF text better
                page_text = pdf.pages[i].extract_text() or ""
                text += page_text + "\n\n"
        return text.strip()
    except Exception as e:
        print(f"Error extracting text from PDF {pdf_path}: {e}")
        return ""