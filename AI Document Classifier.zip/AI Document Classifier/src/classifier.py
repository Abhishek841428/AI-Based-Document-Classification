import os
import json
from groq import Groq
from dotenv import load_dotenv  # <-- add this

# --- Load .env file ---
load_dotenv()  # Reads the .env file in the project root

# --- Groq Client Initialization ---
groq_api_key = os.getenv("GROQ_API_KEY")

try:
    client = Groq(api_key=groq_api_key)
except Exception as e:
    client = None
    print("WARNING: Groq Client failed to initialize. Please ensure GROQ_API_KEY is set.")

# --- SYSTEM PROMPT ---
SYSTEM_PROMPT = """
You are an expert Document Classifier AI. Your task is to classify the provided text into one of four categories: INVOICE, CONTRACT, PURCHASE_ORDER, or UNKNOWN.

CLASSIFICATION RULES:
1. INVOICE: Indicators include 'Tax Invoice', 'Invoice Number', 'Invoice Date', 'Total Amount Due', 'Grand Total', or payment terms.
2. CONTRACT: Indicators include 'Agreement', 'Terms and Conditions', 'Governing Law', 'Parties Involved', 'Effective Date', or signature blocks.
3. PURCHASE_ORDER: Indicators include 'PO Number', 'Shipping Address', 'Requested Delivery Date', or a 'Purchase Order' title.
4. UNKNOWN: If insufficient evidence exists for the other three categories.

OUTPUT FORMAT:
Return a single JSON object only:

{
  "category": "CLASSIFICATION_HERE",
  "reasoning": "Concise explanation of the keywords found."
}
"""

def classify_text(text):
    """
    Classifies text using the Groq Llama 3 API.

    Returns:
        dict: {'category': str, 'reasoning': str}
    """
    load_dotenv()
    api_key = os.getenv("GROQ_API_KEY")
    print("API Key:", api_key)
    if not client:
        return {"category": "unknown", "reasoning": "API Key not set for Groq. Cannot classify."}

    trimmed_text = text[:10000]  # Use up to 10k characters

    try:
        response = client.chat.completions.create(
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"PDF TEXT:\n{trimmed_text}"}
            ],
            model="llama-3.1-8b-instant",
            response_format={"type": "json_object"},
            temperature=0.0
        )

        data = json.loads(response.choices[0].message.content.strip())

        llm_category = data.get("category", "UNKNOWN").lower().replace("_", "")
        reasoning = data.get("reasoning", "No reasoning provided by the model.")

        if "invoice" in llm_category:
            final_category = "invoice"
        elif "purchaseorder" in llm_category or "productorder" in llm_category:
            final_category = "product_order"
        elif "contract" in llm_category:
            final_category = "contract"
        else:
            final_category = "unknown"

        return {"category": final_category, "reasoning": reasoning}

    except Exception as e:
        error_msg = f"Groq API or Parsing Error: {e}"
        print(error_msg)
        return {"category": "unknown", "reasoning": error_msg}
