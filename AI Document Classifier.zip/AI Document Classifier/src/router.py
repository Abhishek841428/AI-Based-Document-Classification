import shutil
import os
import tempfile
from src.extract_text import extract_text
from src.classifier import classify_text

def process_and_route_uploaded_files(uploaded_files):
    """
    Process uploaded PDFs:
    - Extract text
    - Classify
    - Route to department folder
    """
    # Create necessary directories
    os.makedirs("data/input", exist_ok=True)
    base_processed = "data/processed"
    os.makedirs(base_processed, exist_ok=True)

    results = []

    # Mapping of final category to folder name
    mapping = {
        "invoice": "finance",
        "product_order": "procurement",
        "contract": "legal",
        "unknown": "others"
    }

    for uploaded_file in uploaded_files:
        # 1. Save temp PDF
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
            tmp_file.write(uploaded_file.read())
            input_path = tmp_file.name # Path to the temporary file

        # 2. Extract text
        text = extract_text(input_path)

        # 3. Classify (returns a dict: {'category': str, 'reasoning': str})
        classification_result = classify_text(text)
        category = classification_result["category"]
        reasoning = classification_result["reasoning"]

        # 4. Route to folder
        folder_name = mapping.get(category, "others")
        dest_folder = os.path.join(base_processed, folder_name)
        os.makedirs(dest_folder, exist_ok=True)
        
        # Define final destination path using the original filename
        final_dest_path = os.path.join(dest_folder, uploaded_file.name)
        
        # Move the temporary file to its final destination
        try:
            shutil.move(input_path, final_dest_path)
        except Exception as e:
            # Handle case where file might already exist or move failed
            print(f"Error moving file {uploaded_file.name}: {e}")
            # Ensure the temp file is cleaned up if move fails
            if os.path.exists(input_path):
                 os.remove(input_path)
            reasoning = f"File move failed ({e}). Category: {category}. Original Reason: {reasoning}"
            
        results.append({
            "filename": uploaded_file.name,
            "category": category,
            "destination": dest_folder,
            "summary": reasoning 
        })

    return results