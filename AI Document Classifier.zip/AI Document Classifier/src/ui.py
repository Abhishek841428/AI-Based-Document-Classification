import streamlit as st
import pandas as pd
import plotly.express as px
from src.router import process_and_route_uploaded_files

# --------------------------------------------------
# PAGE CONFIG
# --------------------------------------------------
st.set_page_config(
    page_title="AI PDF Console",
    page_icon="🛸",
    layout="wide",
)

# --------------------------------------------------
# GLOBAL CSS
# --------------------------------------------------
st.markdown("""
<style>
html, body, [class*="css"] {
    font-family: "Consolas", "Roboto Mono", monospace;
    background-color: #0a0f1e !important;
    color: #e0e0e0;
}

section[data-testid="stSidebar"] {
    background: linear-gradient(180deg, rgba(0,200,255,0.05), rgba(0,140,255,0.08));
    border-right: 2px solid rgba(0,200,255,0.2);
    backdrop-filter: blur(8px);
    padding-top: 10px;
}

.holo-card {
    padding: 16px;
    border-radius: 12px;
    margin-bottom: 10px;
    background: rgba(0,120,255,0.05);
    border: 1px solid rgba(0,200,255,0.15);
    box-shadow: 0 1px 8px rgba(0,200,255,0.08);
    transition: 0.2s ease-in-out;
}

.holo-card:hover {
    transform: scale(1.01);
    box-shadow: 0 0 18px rgba(0,200,255,0.2);
}

.glow {
    color: #00c8ff;
    text-shadow: 0 0 6px #00b4ff, 0 0 12px #0099ff;
}

.stat-box {
    background: rgba(0,150,255,0.07);
    border: 1px solid rgba(0,200,255,0.15);
    border-radius: 8px;
    padding: 10px;
    margin-bottom: 6px;
}

.upload-box {
    background: rgba(0,120,255,0.02);
    padding: 12px;
    border-radius: 10px;
    border: 1px solid rgba(0,200,255,0.12);
    box-shadow: 0 1px 4px rgba(0,200,255,0.05);
}

.upload-header {
    padding: 20px;
    text-align:center;
    font-size:18px;
    background-color: rgba(255,255,255,0.01);
    border-radius:12px;
    color:#00c8ff;
    transition: 0.3s;
    box-shadow: 0 0 12px rgba(0,200,255,0.1);
}

.upload-header:hover {
    box-shadow: 0 0 20px rgba(0,200,255,0.3);
}
</style>
""", unsafe_allow_html=True)

# --------------------------------------------------
# HEADER
# --------------------------------------------------
st.markdown("""
<div style='padding:16px; text-align:center;'>
    <h1 class='glow'>🛸 AI PDF Classification Console</h1>
    <p style='color:#a0c4ff; font-size:14px;'>Automatic routing to Finance, Procurement, and Legal departments</p>
</div>
""", unsafe_allow_html=True)

# --------------------------------------------------
# SIDEBAR
# --------------------------------------------------
st.sidebar.markdown("## 🔍 Search & Filter")
search_query = st.sidebar.text_input("Search files")
category_filter = st.sidebar.selectbox(
    "Filter by category",
    ["All", "Invoice", "Product Order", "Contract", "Unknown"]
)
st.sidebar.markdown("---")
st.sidebar.markdown("## 📡 System Status")
sb_uploaded = st.sidebar.empty()
sb_processed = st.sidebar.empty()

# --------------------------------------------------
# MODERN DRAG & DROP FILE UPLOADER
# --------------------------------------------------
st.markdown("<div class='upload-header'>📂 Drop PDF files here or click to select</div>", unsafe_allow_html=True)
uploaded_files = st.file_uploader("", type=["pdf"], accept_multiple_files=True)

# --------------------------------------------------
# DISPLAY UPLOADED FILES
# --------------------------------------------------
if uploaded_files:
    with st.expander(f"📁 Uploaded Files ({len(uploaded_files)})", expanded=False):
        st.markdown("<div class='upload-box'>", unsafe_allow_html=True)
        seen_files = set()
        for f in uploaded_files:
            if f.name not in seen_files:
                st.markdown(f"📄 {f.name}", unsafe_allow_html=True)
                seen_files.add(f.name)
        st.markdown("</div>", unsafe_allow_html=True)

# --------------------------------------------------
# CATEGORY COLORS & DEPARTMENTS
# --------------------------------------------------
categories = ["invoice", "product_order", "contract", "unknown"]
category_colors = {
    "invoice": "#7CFC00",      # neon green
    "product_order": "#1E90FF", # bright blue
    "contract": "#FF69B4",     # neon pink
    "unknown": "#9B30FF"       # silver/grey
}
category_icons = {
    "invoice": "🧾",
    "product_order": "📦",
    "contract": "📜",
    "unknown": "❓"
}
dept_mapping = {
    "invoice": "Finance Department",
    "product_order": "Procurement Department",
    "contract": "Legal Department",
    "unknown": "Unknown Department"
}

# --------------------------------------------------
# PROCESS FILES
# --------------------------------------------------
results = []
if uploaded_files:
    sb_uploaded.info(f"Uploaded Files: {len(uploaded_files)}")
    with st.spinner("🔍 Classifying PDFs..."):
        results = process_and_route_uploaded_files(uploaded_files)

    counts = {c: 0 for c in categories}
    for r in results:
        counts[r["category"]] += 1

    sb_processed.markdown("### ⚡ Processed Summary")
    for cat, cnt in counts.items():
        st.sidebar.markdown(
            f"<div class='stat-box'><b>{cat.replace('_',' ').title()}:</b> {cnt}</div>",
            unsafe_allow_html=True
        )

# --------------------------------------------------
# MAIN CONTENT
# --------------------------------------------------
if results:
    st.markdown("## 🛰️ Analysis Deck")

    grouped = {c: [] for c in categories}
    for r in results:
        grouped[r["category"]].append(r)

    for category in categories:
        items = grouped[category]
        if not items:
            continue

        df_cat = pd.DataFrame([{
            "Filename": r["filename"],
            "Category": r["category"],
            "Routed To": dept_mapping.get(r["category"], "Unknown Department"),
            "Summary": r["summary"]
        } for r in items])

        with st.expander(f"{category_icons[category]} {category.replace('_',' ').title()} ({len(items)})", expanded=False):
            cols = st.columns([6,1])
            with cols[1]:
                st.download_button(
                    "💾 Export CSV",
                    data=df_cat.to_csv(index=False).encode("utf-8"),
                    file_name=f"{category}_results.csv",
                    mime="text/csv",
                    key=f"dl_{category}"
                )

            for r in items:
                if ((search_query.lower() in r["filename"].lower())
                    and (category_filter.lower() == "all"
                         or r["category"].replace("_", " ") == category_filter.lower())):

                    routed_display = dept_mapping.get(r["category"], "Unknown Department")
                    st.markdown(f"""
                    <div class='holo-card' style='border-left: 3px solid {category_colors[r["category"]]};'>
                        <b>Filename:</b> {r['filename']}<br>
                        <b>Routed To:</b> {routed_display}<br>
                        <b>Summary:</b> {r['summary']}
                    </div>
                    """, unsafe_allow_html=True)

# --------------------------------------------------
# FULL EXPORT
# --------------------------------------------------
if results:
    df_all = pd.DataFrame([{
        "Filename": r["filename"],
        "Category": r["category"],
        "Routed To": dept_mapping.get(r["category"], "Unknown Department"),
        "Summary": r["summary"]
    } for r in results])

    st.markdown("## 🚀 Full Export")
    st.download_button(
        "📥 Export FULL REPORT CSV",
        data=df_all.to_csv(index=False).encode("utf-8"),
        file_name="full_report.csv",
        mime="text/csv",
        key="full_export"
    )

# --------------------------------------------------
# PIE CHART WITH SPACE-NEON COLORS
# --------------------------------------------------
if results:
    st.markdown("## 🪐 Category Distribution")
    space_colors = ["#7CFC00","#1E90FF","#FF69B4","#9B30FF"]  # neon green, cyan, pink, violet
    fig = px.pie(
        names=[c.replace("_"," ").title() for c in counts.keys()],
        values=list(counts.values()),
        color=[c for c in counts.keys()],
        color_discrete_sequence=space_colors
    )
    fig.update_traces(
        hovertemplate="<b>%{label}</b><br>Count: %{value}<br>Percentage: %{percent}",
        textinfo="label+percent"
    )
    fig.update_layout(
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font_color='white'
    )
    st.plotly_chart(fig, use_container_width=True)
